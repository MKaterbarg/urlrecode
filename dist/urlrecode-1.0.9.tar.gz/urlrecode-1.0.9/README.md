# urlrecode

Usage Syntax: urlrecode [parameter] "[string to process]"
          
Parameters:   
    -d      URL Decode string.  
    -e      URL Encode string        

urlrecode expects two command line parameters to be given. Either -d or -e to specify the required action, followed by the string which it should process.


I created urlrecode for the simple reason of needing a simple way to do URL encoding / URL decoding on the command line. Besides that I wanted to start getting into Python development, so I though this would be an excellent project to start learning.
